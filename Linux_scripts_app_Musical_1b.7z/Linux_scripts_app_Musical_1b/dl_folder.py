import os
import subprocess

def choice_folder(current_path, dl_dos):
	while dl_dos != (0,1):
		subprocess.run('clear', shell=True)
		dl_dos = input("Default Folder: " + "{}".format(current_path) + "\nDo you want a specific download folder ?: [y=1/n=0] : ")
		if int(dl_dos) == 1:
			current_path = input("Folder path : ")
			break

		if int(dl_dos) == 0:
			# On récupere le dossier actuel du script
			__file__ = "script.py"
			current_path = os.path.dirname(os.path.abspath(__file__))
			break
	return(current_path)