import subprocess

def test():
	#On teste si ffmpeg est installé pour obtenir correctement les mp3

	command_install_ffmpeg = 'sudo apt-get install ffmpeg'
	ffmpeg_version = subprocess.run('ffmpeg -version', shell=True)

	if ffmpeg_version:
		subprocess.run('clear', shell=True)
	else:
		print("FFMPEG missing.. Downloading...\n")
		if command_install_ffmpeg:
			print("Unpacking...\nDone! FFMPEG has been succesfully downloaded\n")
		else:
			print("Error. Try later|Fix your Internet Connection|Send a report log")
			exit()	
	return()