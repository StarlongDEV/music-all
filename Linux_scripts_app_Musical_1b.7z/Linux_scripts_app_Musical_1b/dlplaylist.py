# -*- coding: utf-8 -*-
"""
Created on Sun Jun  4 20:47:06 2017

@author: Théophile
"""
import os
import subprocess  

def dl_playlist(arglien_playlist, current_path):
    
        #On récupère le titre de la playlist en demande à l'user
        titre_playlist = input("Name of the playlist : ")
        nom_dossier = str(titre_playlist)        
        
        #Nouveau chemin
        newpath = current_path + '/{}'.format(nom_dossier) 
        
        command4 = 'youtube-dl -x -o ' + '"{}'.format(newpath) + '/%(title)s.%(ext)s" --audio-format mp3 ' + arglien_playlist
        
        #Si la musique est déjà téléchargé
        if not os.path.exists(newpath):           
            #Création du Dossier
            print("Folder created!")
            os.makedirs(newpath)
            
        else:
            print("Folder already exist")


        #On effectue le téléchargement
        print("Downloading playlist.. (Can take some time if there is a lot of songs)...")
        do_dl = subprocess.run(command4, shell=True)
        if do_dl:
            print("Playlist downloaded!")
        else:
            print("Error")
            
        