# -*- coding: utf-8 -*-
"""

Music-all
@Théophile Louvart 2017


"""

# On importe les modules utiles 
import dlone as dlONE
import dlplaylist as dlPla
import os
import subprocess
import test_ffmpeg
import dl_folder

#musique https://www.youtube.com/watch?v=IM-xWd7Zeps
#playlist https://www.youtube.com/playlist?list=PLwiyx1dc3P2JR9N8gQaQN_BCvlSlap7re

#Csts
end_use = 2
dl_dos = 2
current_path = os.path.dirname(os.path.abspath(__file__))

#On teste si ffmpeg est installé pour obtenir correctement les mp3
test_ffmpeg.test()

#On demande dans quel dossier on veut télécharger la musique
current_path = dl_folder.choice_folder(current_path, dl_dos)


while int(end_use) != (0,1):
    end_use = input("Voulez-vous télécharger une musique ou une playlist : [Musique:0/Playlist:1/Quit:2] : ")
    
    if int(end_use) == 0:           
        arglien = input("[YOUTUBE DOWNLOADER] Lien de la musique à télécharger : ")
          
        #On effectue
        dlONE.dl(arglien, current_path)
        
    if int(end_use) == 1:   
        arglien_playlist = input('[YOUTUBE DOWNLOADER] Lien de la playlist à télécharger : ')                
        
        #On effectue
        dlPla.dl_playlist(arglien_playlist, current_path)          
    
    else:
        print("\n\nFin du programme")
        break
  
    
